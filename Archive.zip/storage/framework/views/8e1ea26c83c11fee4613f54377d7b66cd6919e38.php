<?php $__env->startSection('content'); ?>

<!-- Form Row Start -->
<section class="scroll-section" id="formRow">
    <!-- <h2 class="small-title">Daftar Pertanyaan</h2> -->

    <div class="card mb-5">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Jenis</th>
                        <th scope="col">Bagian</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td scope="row">1</td>
                        <td scope="row">Pertanyaan Awal</td>
                        <td>
                            <?php if($firstOrLast[0]->stepFirst==null): ?>
                            <a type="button" onclick="choose(event)" href="#" data-jenis="first" data-id="<?php echo e($firstOrLast[0]->id); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal">Tentukan</a>
                            <?php else: ?>
                            <a type="button" onclick="choose(event)" href="#" data-jenis="first" data-id="<?php echo e($firstOrLast[0]->id); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal"><?php echo e($firstOrLast[0]->stepFirst->step_kode."-".$firstOrLast[0]->stepFirst->step_nama); ?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td scope="row">2</td>
                        <td scope="row">Pertanyaan Akhir</td>
                        <td>
                            <?php if($firstOrLast[0]->stepLast==null): ?>
                            <a type="button" onclick="choose(event)" href="#" data-jenis="last" data-id="<?php echo e($firstOrLast[0]->id); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal">Tentukan</a>
                            <?php else: ?>
                            <a type="button" onclick="choose(event)" href="#" data-jenis="last" data-id="<?php echo e($firstOrLast[0]->id); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal"><?php echo e($firstOrLast[0]->stepLast->step_kode."-".$firstOrLast[0]->stepLast->step_nama); ?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
<!-- Form Row End -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelDefault" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <h2 class="small-title"><span id="modal-title"></span></h2>
                <select class="form-select mb-3" id="bagian" required>
                    <option value="">Pilih Bagian</option>
                    <?php $__currentLoopData = $bagianList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bagian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bagian->id); ?>"><?php echo e($bagian->step_kode); ?> - <?php echo e($bagian->step_nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="save">Tentukan Direct</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    let element
    let save = document.querySelector("#save")

    function choose(event) {
        element = event.target
    }
    save.addEventListener('click', async function() {
        let dataSend = new FormData()
        let bagian = document.querySelector("#bagian")

        dataSend.append('id', element.dataset.id)
        dataSend.append('jenis', element.dataset.jenis)
        dataSend.append('bagian_id', bagian.options[bagian.selectedIndex].value)
        response = await fetch('<?php echo e(route("admin.bagian.update.first.Last")); ?>', {
            method: "POST",
            body: dataSend
        })
        responseMessage = await response.json()
        if (responseMessage.status == "sukses") {
            alert("berhasil ubah data")
            element.innerText = bagian.options[bagian.selectedIndex].innerText
        }
        // console.log(responseMessage);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/admin/bagian-pengaturan.blade.php ENDPATH**/ ?>