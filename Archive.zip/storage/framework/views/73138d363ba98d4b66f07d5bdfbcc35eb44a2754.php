<?php
    $html_tag_data = ["override"=>'{ "attributes" : { "placement" : "vertical", "layout":"fluid" }, "storagePrefix" : "starter-project", "showSettings" : false }'];
    $title = 'Vertical Starter Page';
    $description= 'An empty page with a fluid vertical layout.';
    $breadcrumbs = ["/"=>"Home"]
?>


<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_vendor'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_page'); ?>
    <script src="<?php echo e(asset('/js/pages/vertical.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container">
            <div class="row">
                <!-- Title Start -->
                <div class="col-12 col-md-7">
                    <h1 class="mb-0 pb-0 display-4" id="title"><?php echo e($title); ?></h1>
                    <?php echo $__env->make('_layout.breadcrumb',['breadcrumbs'=>$breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!-- Title End -->
            </div>
        </div>
        <!-- Title and Top Buttons End -->

        <!-- Content Start -->
        <div class="card mb-2">
            <div class="card-body h-100"><?php echo e($description); ?></div>
        </div>
        <!-- Content End -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout',[
'html_tag_data'=>$html_tag_data,
'title'=>$title,
'description'=>$description
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/vertical.blade.php ENDPATH**/ ?>