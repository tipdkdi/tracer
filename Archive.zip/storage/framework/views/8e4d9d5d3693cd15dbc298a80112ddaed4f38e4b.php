<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    google.charts.load('current', {
        'packages': ['corechart']
    });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        let dataPertanyaan = <?php echo json_encode($dataPertanyaan[0], 15, 512) ?>;
        let jawaban = [
            ['Task', '<?php echo e($dataPertanyaan[0]->pertanyaan); ?>']
        ]
        dataPertanyaan.jawaban_jenis.map(function(data) {
            jawaban.push([data.pilihan_jawaban, data.total])
        });
        console.log(jawaban);
        var data = google.visualization.arrayToDataTable(
            jawaban
        );
        var options = {
            title: '<?php echo e($dataPertanyaan[0]->pertanyaan); ?>',
            sliceVisibilityThreshold: 0,
            pieHole: 0.4,
        };
        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
    }
</script>
<!-- Form Row Start -->
<!-- Text Content Start -->
<section class="scroll-section" id="textContent">
    <div class="card mb-5">
        <div class="card-body d-flex flex-column">
            <h3 class="card-title mb-4">Laporan Pertanyaan</h3>
            <ul>
                <li>Pertanyaan : <?php echo e($dataPertanyaan[0]->pertanyaan); ?></li>
            </ul>
        </div>
    </div>
</section>
<!-- Text Content End -->
<section class="scroll-section" id="formRow">

    <div class="card mb-5">
        <div class="card-body">
            <div id="piechart" class="col-sm-12" style="height: 500px;"></div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Pilihan Jawaban</th>
                        <th scope="col">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dataPertanyaan[0]->jawabanJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($index+1); ?></th>
                        <td><?php echo e($item->pilihan_jawaban); ?></td>
                        <td><?php echo e($item->total); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<!-- Form Row End -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- <script>
    class Charts {
        constructor() {
            // Initialization of the page plugins
            if (typeof Chart === 'undefined') {
                console.log('Chart is undefined!');
                return;
            }
            this._pieChart = null;
            this._initPieChart();
            _initPieChart() {
                if (document.getElementById('pieChart')) {
                    const pieChart = document.getElementById('pieChart');
                    this._pieChart = new Chart(pieChart, {
                        type: 'pie',
                        data: {
                            labels: ['Breads', 'Pastry', 'Patty'],
                            datasets: [{
                                label: '',
                                borderColor: [Globals.primary, Globals.secondary, Globals.tertiary],
                                backgroundColor: ['rgba(' + Globals.primaryrgb + ',0.1)', 'rgba(' + Globals.secondaryrgb + ',0.1)', 'rgba(' + Globals.tertiaryrgb + ',0.1)'],
                                borderWidth: 2,
                                data: [15, 25, 20],
                            }, ],
                        },
                        draw: function() {},
                        options: {
                            plugins: {
                                datalabels: {
                                    display: false
                                },
                            },
                            responsive: true,
                            maintainAspectRatio: false,
                            title: {
                                display: false,
                            },
                            layout: {
                                padding: {
                                    bottom: 20,
                                },
                            },
                            legend: {
                                position: 'bottom',
                                labels: ChartsExtend.LegendLabels(),
                            },
                            tooltips: ChartsExtend.ChartTooltip(),
                        },
                    });
                }
            }
        }
    }
</script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/admin/laporan.blade.php ENDPATH**/ ?>