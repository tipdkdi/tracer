<!-- Vendor Scripts Start -->
<script src="<?php echo e(asset('/js/vendor/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/OverlayScrollbars.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/autoComplete.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/clamp.min.js')); ?>"></script>
<?php echo $__env->yieldContent('js_vendor'); ?>
<!-- Vendor Scripts End -->
<!-- Template Base Scripts Start -->
<script src="<?php echo e(asset('/font/CS-Line/csicons.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/helpers.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/globals.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/nav.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/search.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/settings.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/init.js')); ?>"></script>
<!-- Template Base Scripts End -->
<!-- Page Specific Scripts Start -->
<?php echo $__env->yieldContent('js_page'); ?>
<script src="<?php echo e(asset('/js/common.js')); ?>"></script>
<!-- Page Specific Scripts End -->
<script src="<?php echo e(asset('/js/scripts.js')); ?>"></script>
<?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/_layout/scripts.blade.php ENDPATH**/ ?>