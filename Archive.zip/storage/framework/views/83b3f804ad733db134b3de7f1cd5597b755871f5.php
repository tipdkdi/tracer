<?php $__env->startSection('content'); ?>

<!-- Form Row Start -->
<!-- Text Content Start -->
<section class="scroll-section" id="textContent">
    <div class="card mb-5">
        <div class="card-body d-flex flex-column">
            <h3 class="card-title mb-4">Informasi Step</h3>
            <ul>
                <li>Kode Step : <?php echo e($bagianData->step_kode); ?></li>
                <li>Nama Step : <?php echo e($bagianData->step_nama); ?></li>
                <li>Pertanyaan : <?php echo e($bagianData->pertanyaan[0]->pertanyaan); ?></li>
            </ul>
        </div>
    </div>
</section>
<!-- Text Content End -->
<section class="scroll-section" id="formRow">
    <div class="card mb-5">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">List Jawaban</th>
                        <th scope="col">Redirect</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bagianData->pertanyaan[0]->jawabanJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($index+1); ?></th>
                        <td><?php echo e($item->pilihan_jawaban); ?></td>
                        <td>
                            <!-- <a href="#"></a> -->
                            <!-- Button Trigger -->
                            <?php if($item->jawabanRedirect==null): ?>
                            <a type="button" onclick="choose(event)" href="#" data-id="<?php echo e($item->id); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal">Tentukan</a>
                            <?php else: ?>
                            <a type="button" onclick="choose(event)" href="#" data-id="<?php echo e($item->id); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal"><?php echo e($item->jawabanRedirect->step->step_kode); ?> - <?php echo e($item->jawabanRedirect->step->step_nama); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a type="button" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Hapus')" href="<?php echo e(route('admin.jenisJawaban.delete',[$bagianData->id,$bagianData->pertanyaan[0]->id,$item->id])); ?>" data-id="<?php echo e($item->id); ?>">Hapus Pilihan Jawaban</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


        </div>
    </div>
</section>
<!-- Form Row End -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelDefault" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <select class="form-select mb-3" id="step" required>
                    <option value="">Pilih Bagian</option>
                    <option value="-">Kosongkan</option>
                    <?php $__currentLoopData = $bagianList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bagian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bagian->id); ?>"><?php echo e($bagian->step_kode); ?> - <?php echo e($bagian->step_nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal" id="delete">Hapus Redirect</button>
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="save">Tentukan Redirect</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    let element

    function choose(event) {
        element = event.target
    }

    document.querySelector("#delete").addEventListener('click', async function() {
        let dataSend = new FormData()
        dataSend.append('jawaban_jenis_id', element.dataset.id)
        response = await fetch('<?php echo e(route("admin.delete.jawaban.redirect")); ?>', {
            method: "POST",
            body: dataSend
        })
        responseMessage = await response.json()
        if (responseMessage.status == "sukses") {
            alert('Redirect Sukses dihapus')
            element.innerText = "Tentukan"
        } else {
            alert('Ada Kesalahan atau Redirect Tidak Ada')
        }
    });
    document.querySelector("#save").addEventListener('click', async function() {
        let dataSend = new FormData()
        let step = document.querySelector("#step")
        // return alert(element.dataset.id)
        if (step.options[step.selectedIndex].value == "")
            return alert('Redirect tidak boleh kosong')
        dataSend.append('jawaban_jenis_id', element.dataset.id)
        dataSend.append('step_id_redirect', step.options[step.selectedIndex].value)
        response = await fetch('<?php echo e(route("admin.store.jawaban.redirect")); ?>', {
            method: "POST",
            body: dataSend
        })
        responseMessage = await response.json()
        if (responseMessage.status == "sukses") {
            alert('sukses')
            element.innerText = step.options[step.selectedIndex].innerText

        }
        console.log(responseMessage);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/admin/kelola-redirect-jawaban.blade.php ENDPATH**/ ?>