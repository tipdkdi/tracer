<?php $__env->startSection('content'); ?>

<div class="card mb-5">
    <div class="card-body">
        <h2>Kuisioner Selesai</h2>
        <p>Terima Kasih atas partisipasi.</p>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-primary">Kembali Ke Beranda</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/user/selesai.blade.php ENDPATH**/ ?>